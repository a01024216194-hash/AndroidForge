# 상상투자 Android 프로젝트 V1.4

## V1.4 변경 사항
- Yahoo Finance Chart API 조회 주기를 일봉(`1d`)에서 1분봉(`1m`)으로 변경하고 프리마켓/애프터마켓 데이터 요청을 추가했습니다.
- 정규장, 프리마켓, 애프터마켓, 최근 정규장 가격을 구분해 표시합니다.
- 제공처가 반환한 시세 기준 시각(`quoteTime`)과 앱 응답 수신 시각(`fetchedAt`)을 분리했습니다.
- 환율 USD/KRW를 조회하지 못하면 임의의 1,400원을 사용하지 않습니다. 미국 주식의 원화 거래를 중단합니다.
- 보유 종목 중 하나라도 유효한 시세를 확인하지 못하면 총자산/수익률 계산을 보류해 잘못된 수익률을 표시하지 않도록 했습니다.
- 기준 시각이 오래된 시세로는 가상 매수/매도를 차단합니다.
- 앱 버전을 1.4로 올렸습니다. 기존 HTML 화면과 모의투자 기능, localStorage 계좌 구조는 유지했습니다.

## 시세 정확도에 관한 중요 안내
이 프로젝트는 Yahoo Finance의 비공식 Chart API를 사용합니다. Yahoo Finance가 모든 종목에 대해 실시간·무지연 시세를 제공한다고 보장할 수 없고, 토스증권과 데이터 공급처·거래소·시세 지연 정책이 다를 수 있습니다. 따라서 V1.4는 데이터 기준 시각을 노출하고 오래된/누락 데이터를 거래 및 수익률 계산에서 차단하는 개선이며, 토스증권과 가격이 항상 일치한다는 보증은 아닙니다.

실제 시세를 더 엄격히 맞추려면 미국 거래소 실시간 데이터 권한이 포함된 공식/상용 API(예: 사용자의 계약이 있는 데이터 제공업체)를 선택하고 API 약관, 지연 여부, 거래소 권한을 확인해야 합니다. 현재 프로젝트에는 그런 인증정보가 포함되어 있지 않습니다.

## 빌드 방법
### Android Studio
1. `sangsang-invest` 폴더를 Android Studio에서 엽니다.
2. Gradle Sync를 진행합니다.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`를 실행합니다.
4. `app/build/outputs/apk/debug/app-debug.apk`를 설치합니다.

### PC 없이 갤럭시에서 빌드 (GitHub Actions)
이 프로젝트에는 `.github/workflows/android-apk.yml`이 포함되어 있습니다.
1. 휴대폰 브라우저에서 GitHub에 로그인하고 새 비공개 저장소를 만듭니다.
2. ZIP을 풀어 `sangsang-invest` 폴더 안의 파일과 `.github` 폴더를 저장소 루트에 업로드합니다. (폴더 구조를 그대로 유지)
3. GitHub 저장소의 `Actions` 탭에서 `Build Android debug APK` 워크플로를 실행합니다.
4. 실행이 끝나면 해당 실행 페이지 하단의 Artifacts에서 `sangsang-invest-debug-apk`를 내려받습니다.
5. ZIP 압축을 풀고 `app-debug.apk`를 눌러 설치합니다. Android가 요청하면 브라우저/파일 앱의 '알 수 없는 앱 설치 허용'을 켭니다.

GitHub Actions 빌드는 클라우드에서 수행되므로 휴대폰에 Android SDK를 설치할 필요가 없습니다. GitHub 계정과 저장소 업로드가 필요합니다.

## 기존 데이터 주의
- 가상 계좌 데이터는 WebView localStorage에 저장됩니다.
- 앱을 업데이트 설치하면 일반적으로 기존 앱 데이터가 유지되지만, 앱 제거/데이터 삭제 시 초기화될 수 있습니다.
- 기존 V1.3 데이터 구조를 유지했으나, 실제 기기에서 업데이트 전 계좌 데이터 백업을 권장합니다.
- 첫 관리자 비밀번호는 기존 설정대로 `1234`입니다. 최초 실행 후 변경하세요.
- 수수료, 세금, 배당금, 기업행사, 분할/병합은 아직 반영하지 않습니다.

## 기술 정보
- Android Gradle Plugin 8.7.3 / Gradle 8.9 / JDK 17
- compileSdk 35, minSdk 23, targetSdk 35
- applicationId: `com.sangsang.invest`
- versionCode: 2, versionName: 1.4


## V1.4.1 국내주식 등락률 보정
- 국내(.KS/.KQ) 종목은 `regularMarketPreviousClose`를 우선 사용하고, 없으면 `previousClose`를 사용합니다.
- 두 기준값이 모두 없으면 `chartPreviousClose`로 임의 계산하지 않고 등락률을 '확인 불가'로 표시합니다.
- 화면에 변동 기준을 함께 표시해 전일 종가 기반인지 확인할 수 있습니다.
- 이 수정은 데이터 제공처의 원천 정확성을 보장하지 않습니다. 토스증권과 정확히 일치시키려면 한국거래소 또는 국내 증권사 시세 API의 공식 전일 종가/현재가 연동과 검증이 필요합니다.
