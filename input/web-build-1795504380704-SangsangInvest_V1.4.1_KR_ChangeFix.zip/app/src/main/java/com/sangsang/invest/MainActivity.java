package com.sangsang.invest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
public class MainActivity extends Activity {
 private WebView web;
 @Override public void onCreate(Bundle saved) {
  super.onCreate(saved); web=new WebView(this);
  web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
  web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
  web.addJavascriptInterface(new MarketBridge(),"Market"); setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 public class MarketBridge {
  @JavascriptInterface public String getQuote(String symbol) {
   HttpURLConnection c=null;
   try {
    String safe=symbol.replaceAll("[^A-Za-z0-9.^=_-]","");
    if(safe.length()==0)return error("잘못된 종목 코드");
    URL u=new URL("https://query1.finance.yahoo.com/v8/finance/chart/"+safe+"?range=1d&interval=1m&includePrePost=true");
    c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("GET");
    c.setConnectTimeout(10000); c.setReadTimeout(10000);
    c.setRequestProperty("User-Agent","Mozilla/5.0 SangsangInvest/1.4");
    c.setRequestProperty("Accept","application/json");
    int status=c.getResponseCode();
    if(status<200||status>=300)return error("시세 제공처 응답 오류 (HTTP "+status+")");
    BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
    StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); r.close();
    JSONObject chart=new JSONObject(b.toString()).getJSONObject("chart");
    if(chart.isNull("result")||chart.getJSONArray("result").length()==0)return error("시세 데이터 없음");
    JSONObject meta=chart.getJSONArray("result").getJSONObject(0).getJSONObject("meta");
    String marketState=meta.optString("marketState","UNKNOWN").toUpperCase();
    double price=meta.optDouble("regularMarketPrice",Double.NaN);
    // 국내 종목은 당일 등락률 기준가를 우선 검증된 전일 종가 필드에서 선택한다.
    // chartPreviousClose는 공급처의 차트 기준값일 수 있어 국내 종목에서 무조건 우선하지 않는다.
    boolean korean=safe.endsWith(".KS") || safe.endsWith(".KQ");
    double prev=Double.NaN;
    String changeBasis="";
    if(korean) {
     if(meta.has("regularMarketPreviousClose") && meta.optDouble("regularMarketPreviousClose",Double.NaN)>0) {
      prev=meta.optDouble("regularMarketPreviousClose",Double.NaN); changeBasis="전일 정규장 종가";
     } else if(meta.has("previousClose") && meta.optDouble("previousClose",Double.NaN)>0) {
      prev=meta.optDouble("previousClose",Double.NaN); changeBasis="전일 종가";
     }
    } else {
     if(meta.has("regularMarketPreviousClose") && meta.optDouble("regularMarketPreviousClose",Double.NaN)>0) {
      prev=meta.optDouble("regularMarketPreviousClose",Double.NaN); changeBasis="전일 정규장 종가";
     } else if(meta.has("chartPreviousClose") && meta.optDouble("chartPreviousClose",Double.NaN)>0) {
      prev=meta.optDouble("chartPreviousClose",Double.NaN); changeBasis="차트 전일 종가";
     } else if(meta.has("previousClose") && meta.optDouble("previousClose",Double.NaN)>0) {
      prev=meta.optDouble("previousClose",Double.NaN); changeBasis="전일 종가";
     }
    }
    long quoteTime=meta.optLong("regularMarketTime",0L); String priceType="최근 정규장 가격";
    if("REGULAR".equals(marketState))priceType="정규장";
    else if("PRE".equals(marketState)){double v=meta.optDouble("preMarketPrice",Double.NaN);if(!Double.isNaN(v)&&v>0){price=v;quoteTime=meta.optLong("preMarketTime",quoteTime);priceType="프리마켓";}else priceType="프리마켓 가격 미제공 · 최근 정규장 가격";}
    else if("POST".equals(marketState)||"POSTPOST".equals(marketState)){double v=meta.optDouble("postMarketPrice",Double.NaN);if(!Double.isNaN(v)&&v>0){price=v;quoteTime=meta.optLong("postMarketTime",quoteTime);priceType="애프터마켓";}else priceType="애프터마켓 가격 미제공 · 최근 정규장 가격";}
    if(Double.isNaN(price)||price<=0||quoteTime<=0)return error("유효한 가격 또는 시세 기준 시각이 없습니다.");
    // 국내 종목은 전일 종가 필드가 확인되지 않으면 상승률을 추정하지 않는다.
    boolean changeVerified=!Double.isNaN(prev)&&prev>0;
    JSONObject out=new JSONObject(); out.put("ok",true); out.put("symbol",safe); out.put("price",price);
    if(changeVerified) { out.put("previousClose",prev); out.put("changePct",(price-prev)/prev*100.0); }
    else { out.put("previousClose",JSONObject.NULL); out.put("changePct",JSONObject.NULL); }
    out.put("changeVerified",changeVerified); out.put("changeBasis",changeBasis);
    out.put("currency",meta.optString("currency","")); out.put("exchange",meta.optString("exchangeName",""));
    out.put("marketState",marketState); out.put("priceType",priceType); out.put("quoteTime",quoteTime);
    out.put("fetchedAt",System.currentTimeMillis()/1000L); out.put("exchangeDataDelayedBy",meta.optInt("exchangeDataDelayedBy",-1));
    return out.toString();
   } catch(Exception e){return error("시세 조회 실패: "+e.getMessage());}
   finally{if(c!=null)c.disconnect();}
  }
  private String error(String message){try{JSONObject o=new JSONObject();o.put("ok",false);o.put("error",message);return o.toString();}catch(Exception e){return "{\"ok\":false}";}}
  @JavascriptInterface public void toast(String message){runOnUiThread(()->Toast.makeText(MainActivity.this,message,Toast.LENGTH_SHORT).show());}
 }
}
