package com.sangsang.invest;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new MarketBridge(), "Market");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    public class MarketBridge {
        @JavascriptInterface public String getQuote(String symbol) {
            HttpURLConnection c = null;
            try {
                String safe = symbol.replaceAll("[^A-Za-z0-9.^=_-]", "");
                URL u = new URL("https://query1.finance.yahoo.com/v8/finance/chart/" + safe + "?range=5d&interval=1d");
                c = (HttpURLConnection)u.openConnection();
                c.setRequestMethod("GET"); c.setConnectTimeout(8000); c.setReadTimeout(8000);
                c.setRequestProperty("User-Agent", "Mozilla/5.0 SangsangInvest/1.0");
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                StringBuilder b = new StringBuilder(); String line;
                while ((line = r.readLine()) != null) b.append(line);
                r.close();
                JSONObject root = new JSONObject(b.toString()).getJSONObject("chart").getJSONArray("result").getJSONObject(0);
                JSONObject meta = root.getJSONObject("meta");
                double price = meta.optDouble("regularMarketPrice", Double.NaN);
                double prev = meta.optDouble("chartPreviousClose", meta.optDouble("previousClose", Double.NaN));
                if (Double.isNaN(price) || Double.isNaN(prev) || prev == 0) return "{\"ok\":false,\"error\":\"시세 데이터 없음\"}";
                JSONObject out = new JSONObject(); out.put("ok", true); out.put("symbol", safe);
                out.put("price", price); out.put("previousClose", prev); out.put("changePct", (price-prev)/prev*100);
                out.put("currency", meta.optString("currency", ""));
                out.put("exchange", meta.optString("exchangeName", ""));
                out.put("marketTime", meta.optLong("regularMarketTime", 0));
                return out.toString();
            } catch (Exception e) {
                try { JSONObject out = new JSONObject(); out.put("ok", false); out.put("error", "시세 조회 실패: " + e.getMessage()); return out.toString(); }
                catch (Exception ignored) { return "{\"ok\":false}"; }
            } finally { if (c != null) c.disconnect(); }
        }
        @JavascriptInterface public void toast(String message) { runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show()); }
    }
}
